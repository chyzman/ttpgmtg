import { jsxInTTPG } from "jsx-in-ttpg";

console.log("hello world");
