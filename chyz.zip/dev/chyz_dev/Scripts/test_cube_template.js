"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var api_1 = require("@tabletop-playground/api");
(function (obj) {
    obj.addCustomAction("test", "idfk man", "test");
    obj.onTick.add(function (o) {
        obj.setPrimaryColor(new api_1.Color(Math.random(), Math.random(), Math.random()));
    });
})(api_1.refObject);
